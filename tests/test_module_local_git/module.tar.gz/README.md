# DummySnakemakeModule

Dummy snakemake module used for testing
